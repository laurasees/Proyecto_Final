# Analisis Estadístico y Exploratorio (EDA)
# Estadística descriptiva de ventas, cantidades y márgenes (media, mediana, desviación estándar, min, max, percentiles).
# Análisis por Categoría: Facturación total, unidades vendidas y margen por tipo de producto.
# Análisis Operativo: Tasa de cancelación y distribución de estados de envío (Courier Status / Status).
# Matriz de Correlación: Relación entre precio, costes, cantidad y márgenes.

import os
import pandas as pd
import numpy as np

# 1. Cargar el dataset procesado
BASE_DIR = "/Users/lauraserra/Desktop/archive-2"
file_path = os.path.join(BASE_DIR, "ecommerce_final_clean.csv")

df = pd.read_csv(file_path, low_memory=False)

print("="*60)
print("     ANÁLISIS ESTADÍSTICO Y EXPLORATORIO (EDA)")
print("="*60)

# 2. Resumen Estadístico Descriptivo de Variables Numéricas
cols_num=['Qty', 'Amount', 'Total_Sales_Amount', 'Avg_Cost_TP', 'Gross_Margin_Est']
print("\n--- 1. Estadísticas Descriptivas Principales ---")
stats_df= df[cols_num].describe().T[['mean', 'std', 'min', '50%', 'max']]
print(stats_df.round(2))

# 3. Métricas Clave Operativas (KPIs Globales)
total_ventas = df['Total_Sales_Amount'].sum()
total_unidades = df['Qty'].sum()
ticket_medio = df[df['Amount'] > 0]['Amount'].mean()
pedidos_totales = len(df)

print("\n--- 2. KPIS Globales de Negocio ---")
print(f"• Facturación Total: ${total_ventas:,.2f}")
print(f"• Unidades Vendidas Totales: {total_unidades:,}")
print(f"• Ticket Medio por Venta: ${ticket_medio:.2f}")
print(f"• Número Total de Registros/Pedidos: {pedidos_totales:,}")

# 4. Análisis por Categoría de Producto
print("\n--- 3. Top 5 Categorias por Facturación ---")
if 'Category_amazon' in df.columns:
    cat_col = 'Category_amazon'
elif 'Category' in df.columns:
    cat_col = 'Category'
else:
    cat_col = df.filter(like='Category').columns[0]

top_cat = df.groupby(cat_col).agg(
    Facturacion_Total=('Total_Sales_Amount', 'sum'),
    Unidades_Vendidas=('Qty', 'sum'),
    Precio_Medio=('Amount', 'mean'),
    Margen_Promedio=('Gross_Margin_Est', 'mean')
).sort_values(by='Facturacion_Total', ascending=False)

print(top_cat.head().round(2))

# 5. Análisis de Estado de Envíos (Operaciones)
print("\n--- 4. Distribución del estado de los pedidos (logística) ---")
if 'Status' in df.columns:
    status_dist = df['Status'].value_counts(normalize=True).head(5) * 100
    for status, pct in status_dist.items():
        print(f"• {status}: {pct:.2f}%")

# 6. Matriz de Correlación
print("\n--- 5. Matriz de Correlación ---")
corr_matrix = df[cols_num].corr()
print(corr_matrix.round(2))


# Conclusiones una vez ejecutamos el código:

# Tenemos una tasa de cancelación del 14.21%, lo cual es un dato fundamental para el análisis logístico.
# La categoría Set lidera la facturación con más de 37.9M, seguida de kurta con 20.6M.
# Observación sobre Avg_Cost_TP: En las métricas aparece en 0.00 porque en el JOIN muchos SKUs de la tabla de Amazon no cruzaron con costos de la tabla de P&L o venían vacíos.