# Cargaremos ambos archivos csv, estandarizaremos las claves primarias, realizaremos el left join 

import os
import pandas as pd
import numpy as np

# Ruta apuntando a la carpeta "archive-2" en el Escritorio
BASE_DIR = "/Users/lauraserra/Desktop/archive-2"

path_amazon = os.path.join(BASE_DIR, "Amazon Sale Report.csv")
path_pl = os.path.join(BASE_DIR, "P  L March 2021.csv")

if not os.path.exists(path_amazon) or not os.path.exists(path_pl):
    raise FileNotFoundError("Revisa que los archivos CSV estén dentro de la carpeta archive-2 en el Escritorio.")

print("Cargando archivos CSV...")
df_amazon = pd.read_csv(path_amazon, low_memory=False)
df_pl = pd.read_csv(path_pl, low_memory=False)

print(f"Dimensiones iniciales Amazon: {df_amazon.shape}")
print(f"Dimensiones iniciales P&L: {df_pl.shape}")

# Estandarización de la clave primaria (SKU)
df_amazon['SKU_clean'] = df_amazon['SKU'].astype(str).str.strip().str.upper()
df_pl['SKU_clean'] = df_pl['Sku'].astype(str).str.strip().str.upper()

# Eliminamos duplicados en el catálogo P&L
df_pl_unique = df_pl.drop_duplicates(subset=['SKU_clean'])

# Join / Merge
df_merged = pd.merge(
    df_amazon, 
    df_pl_unique, 
    on='SKU_clean', 
    how='left', 
    suffixes=('_amazon', '_pl')
)

print(f"\nDimensiones tras el JOIN: {df_merged.shape}")

# Función auxiliar para limpiar y convertir números
def clean_numeric(series):
    # Convierte a texto, quita espacios, comas y caracteres no numéricos
    s = series.astype(str).str.replace(',', '').str.replace('$', '').str.strip()
    return pd.to_numeric(s, errors='coerce')

# Convertimos a numéricas las columnas monetarias y de costes
for col in ['TP 1', 'TP 2', 'Amount', 'Qty']:
    if col in df_merged.columns:
        df_merged[col] = clean_numeric(df_merged[col])

# Rellenar valores nulos iniciales
df_merged['Qty'] = df_merged['Qty'].fillna(0).astype(int)
df_merged['Amount'] = df_merged['Amount'].fillna(0.0)
df_merged['TP 1'] = df_merged['TP 1'].fillna(0.0)
df_merged['TP 2'] = df_merged['TP 2'].fillna(0.0)

# Conversión de Fechas sin avisos de warning
df_merged['Date'] = pd.to_datetime(df_merged['Date'], format='mixed', errors='coerce')

# Creación de variables calculadas (Feature Engineering)
df_merged['Total_Sales_Amount'] = df_merged['Qty'] * df_merged['Amount']

# Promedio numérico de coste (TP 1 y TP 2)
df_merged['Avg_Cost_TP'] = df_merged[['TP 1', 'TP 2']].mean(axis=1)

# Margen Bruto Unitario Estimado
df_merged['Gross_Margin_Est'] = df_merged['Amount'] - df_merged['Avg_Cost_TP']


# Guardar el archivo limpio resultante
output_path = os.path.join(BASE_DIR, "ecommerce_final_clean.csv")
df_merged.to_csv(output_path, index=False)
print(f"\n¡Dataset procesado guardado exitosamente en: {output_path}!")